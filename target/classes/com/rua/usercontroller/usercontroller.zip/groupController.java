package com.rua.usercontroller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.*;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;

import model.Grade;
import model.Group;
import model.GroupMember;
import model.HibernateUtil;
import model.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.jxls.reader.ReaderBuilder;
import net.sf.jxls.reader.XLSReader;
import net.sf.jxls.transformer.Workbook;
import net.sf.jxls.transformer.XLSTransformer;

@Controller
public class groupController {
	@RequestMapping(value="/d")
	public void test(){
		//createGroup(1,"ruaruarua");
		//createGroup(2,"fel");
		//submitGroup(2);
		//deleteGroup(3);
		//createGroup(4,"gayll");
	}
	@RequestMapping(value="/createG")
	public void createGroup(HttpServletRequest request,HttpServletResponse response){//int manager_id,String group_name
		Session session= HibernateUtil.factory.openSession();
		String manager_id=request.getParameter("id");
		//System.out.println(manager_id);
		String group_name=request.getParameter("group_name");
		//System.out.println(group_name);
		try{
			Transaction ts=session.getTransaction();
			session.beginTransaction();
			Query query=session.createQuery("alter table group auto_increment=1");
			query.executeUpdate();
			Group group=new Group();
			group.setManagerId(Integer.parseInt(manager_id));
			group.setName(group_name);
			group.setStatus((byte)0);
			session.save(group);
			session.getTransaction().commit();
			
		}catch(Exception e){e.printStackTrace();session.getTransaction().rollback();}
		finally{
			session.close();
		}
	}
	
	public void submitGroup(HttpServletRequest request,HttpServletResponse response){//int group_id
		Session session= HibernateUtil.factory.openSession();
		String group_id=request.getParameter("group_id");
		String name=request.getParameter("name");
		try{
			Transaction ts=session.getTransaction();
			session.beginTransaction();
			Query query=session.createQuery("update Group set status=1 where Name='"+name+"'");
			query.executeUpdate();
			Query query1=session.createQuery(";");
			query1.executeUpdate();
			
			session.getTransaction().commit();
			
		}catch(Exception e){e.printStackTrace();session.getTransaction().rollback();}
		finally{
			session.close();
		}
	}
	
	@RequestMapping(value="/tc-delG")
	public void deleteGroup(@RequestBody String request){//int group_id
		Session session= HibernateUtil.factory.openSession();
		String name=JSONObject.fromObject(request).get("name").toString();
		System.out.println(JSONObject.fromObject(request));
		//String group_id=request.getParameter("group_id");
		//String name=request.getParameter("name");
		try{
			Transaction ts=session.getTransaction();
			session.beginTransaction();
			Query query=session.createQuery("delete from Group where Name='"+name+"'");
			query.executeUpdate();
			session.getTransaction().commit();
			
		}catch(Exception e){e.printStackTrace();session.getTransaction().rollback();}
		finally{
			session.close();
		}
	}
	
	public void checkGroup(@RequestBody String request){//int group_id,byte status
		Session session= HibernateUtil.factory.openSession();
		JSONObject json=JSONObject.fromObject(request);
		String name=json.get("name").toString();
		String status=json.get("status").toString();
		System.out.println(JSONObject.fromObject(request));
		try{
			Transaction ts=session.getTransaction();
			session.beginTransaction();
			Query query=session.createQuery("update Group set status="+status+" where Name='"+name+"'");
			query.executeUpdate();
			session.getTransaction().commit();
			
		}catch(Exception e){e.printStackTrace();session.getTransaction().rollback();}
		finally{
			session.close();
		}
	}
	
	@RequestMapping(value="/tc-getAcc",method=RequestMethod.GET)
	@ResponseBody
	public String getAcc(HttpServletRequest request,HttpServletResponse response){//int group_id,byte status
		JSONObject json=new JSONObject();
		Session session= HibernateUtil.factory.openSession();
		List<Group> group=new ArrayList<Group>();
		int count;
		try{
			Transaction ts=session.getTransaction();
			session.beginTransaction();
			Query query=session.createQuery("from Group where status=2");
			group=query.list();count=group.size();
			json.put("count", count);
			JSONArray array=new JSONArray();
			for(int i=0;i<count;i++){
				JSONObject tmp=new JSONObject();
				tmp.put("name", group.get(i).getName());
				Query query1=session.createQuery("from User where id="+group.get(i).getManagerId());
				List<User> user=query1.list();
				tmp.put("leader", user.get(0).getName());
				String member="";
				Query query2=session.createQuery("from GroupMember a where a.id.groupId="+group.get(i).getId());
				List<GroupMember> gMember=query2.list();
				for(int j=0;j<gMember.size();j++){
					List<User> rua=session.createQuery("from User where Id="+gMember.get(j).getId().getMemberId()).list();
					member+=(rua.get(j).getName()+" ");
				}
				tmp.put("member", member.toString());
				array.add(tmp);
			}
			json.put("team", array);
		}catch(Exception e){e.printStackTrace();session.getTransaction().rollback();return null;}
		finally{
			session.close();
		}
		System.out.println(json.toString());
		return json.toString();
		
	}
	
	@RequestMapping(value="/tc-getG",method=RequestMethod.GET)
	@ResponseBody
	public String getGroup(HttpServletRequest request,HttpServletResponse response){//int group_id,byte status
		JSONObject json=new JSONObject();
		Session session= HibernateUtil.factory.openSession();
		List<Group> group=new ArrayList<Group>();
		int count;
		try{
			Transaction ts=session.getTransaction();
			session.beginTransaction();
			Query query=session.createQuery("from Group where status=1");
			group=query.list();count=group.size();
			json.put("count", count);
			JSONArray array=new JSONArray();
			for(int i=0;i<count;i++){
				JSONObject tmp=new JSONObject();
				tmp.put("name", group.get(i).getName());
				Query query1=session.createQuery("from User where id="+group.get(i).getManagerId());
				List<User> user=query1.list();
				tmp.put("leader", user.get(0).getName());
				String member="";
				Query query2=session.createQuery("from GroupMember a where a.id.groupId="+group.get(i).getId());
				List<GroupMember> gMember=query2.list();
				for(int j=0;j<gMember.size();j++){
					List<User> rua=session.createQuery("from User where Id="+gMember.get(j).getId().getMemberId()).list();
					member+=(rua.get(j).getName()+" ");
				}
				tmp.put("member", member.toString());
				array.add(tmp);
			}
			json.put("team", array);
		}catch(Exception e){e.printStackTrace();session.getTransaction().rollback();return null;}
		finally{
			session.close();
		}
		System.out.println(json.toString());
		return json.toString();
		
	}

}

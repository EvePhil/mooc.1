package com.rua.usercontroller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.*;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;

import model.Application;
import model.Grade;
import model.Group;
import model.GroupMember;
import model.GroupMemberId;
import model.HibernateUtil;
import model.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.jxls.reader.ReaderBuilder;
import net.sf.jxls.reader.XLSReader;
import net.sf.jxls.transformer.Workbook;
import net.sf.jxls.transformer.XLSTransformer;

@Controller
public class applicationController {
	
	@RequestMapping(value="/s")
	public void test(){
		//addApplication("1231","252651");
	}
	
	@RequestMapping(value="/1",method=RequestMethod.POST)
	public void addApplication(HttpServletRequest request,HttpServletResponse response){//int student_id,int group_id
		Session session=HibernateUtil.factory.openSession();
		//JSONArray array=JSONArray.fromObject(request);
		try{
		String student_id=request.getParameter("student_id");
		String name =request.getParameter("name");
		session.beginTransaction();
		List<Group> group=session.createQuery("from group where Name="+name).list();
		int group_id=group.get(0).getId();
		Application app=new Application(Integer.parseInt(student_id),(group_id),(byte)0);
		session.save(app);
		session.getTransaction().commit();
		}catch(Exception e){
			e.printStackTrace();
			session.getTransaction().rollback();
		}finally{
			session.close();
		}
	}
	
	@RequestMapping(value="stu-team-status",method=RequestMethod.GET)
	public @ResponseBody String checkStatus(@RequestBody String request){
		System.out.println(request);
		Session session=HibernateUtil.factory.openSession();
		JSONObject json=JSONObject.fromObject(request);
		JSONObject res=new JSONObject();
		String stuname=json.get("stuName").toString();
		System.out.println(stuname);
		try{
		session.beginTransaction();
		List<User> user=session.createQuery("from User where name="+stuname).list();
		int stuid=user.get(0).getId();
		List<GroupMember> gm=session.createQuery("from GroupMember a where a.id.memberID="+stuid).list();
		if(gm.size()==0){
			res.put("status", 0);
			System.out.println(res);
			return res.toString();
		}
		else{
			List<Group> gp=session.createQuery("from Group where ID="+gm.get(0).getId().getGroupId()).list();
			if(gp.get(0).getManagerId()==stuid){
				res.put("status", 1);
			}
			else res.put("status", 2);
		}
		System.out.println(res);
		return res.toString();
		}catch(Exception e){
			e.printStackTrace();
			session.getTransaction().rollback();
			return null;
		}finally{
			session.close();
		}
	}
	
	@RequestMapping(value="stu-team-manage-approval",method=RequestMethod.POST)
	public void checkApplication(@RequestBody String request){
		Session session=HibernateUtil.factory.openSession();
		JSONObject json=JSONObject.fromObject(request);
		String stuname=json.get("stuName").toString();
		String status=json.getString("status");
		try{
			session.beginTransaction();
			List<User> user=session.createQuery("from User where name="+stuname).list();
			int stuid=user.get(0).getId();
		Query query=session.createQuery("update Application set status="+status+" where student_id="+stuid);
		if(status.equals("1")) {//更新成员表
			Query query1=session.createQuery("select from Application where student_id="+stuid);
			List<Application> app=query1.list();
			GroupMember member=new GroupMember();
			GroupMemberId id=new GroupMemberId();
			id.setGroupId(app.get(0).getGroupId());
			id.setMemberId(app.get(0).getStudentId());
			member.setId(id);
			session.save(member);
		}
		session.getTransaction().commit();
		}catch(Exception e){
			e.printStackTrace();
			session.getTransaction().rollback();
		}finally{
			session.close();
		}
	}
	
	public byte noteApplication(HttpServletRequest request,HttpServletResponse response){//int student_id
		Session session=HibernateUtil.factory.openSession();
		try{
		String student_id=request.getParameter("student_id");
		session.beginTransaction();
		Query query=session.createQuery("select from Application where student_id="+student_id);
		List<Application> app=query.list();
		byte stus=app.get(0).getStatus();
		if(stus!=(byte)0){
			Query query1=session.createQuery("delete from Application where student_id="+student_id);
			query1.executeUpdate();
			session.getTransaction().commit();
		}
		System.out.println(stus);
		
		return app.get(0).getStatus();
		
		}catch(Exception e){
			e.printStackTrace();
			session.getTransaction().rollback();
			return 4;
		}finally{
			session.close();
		}
	}
	

}

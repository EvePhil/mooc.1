$(document).ready(function(){
    // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
    $('.modal').modal();
});
$('.teamlist').click(function () {
    var _this=this;
//        $(_this).find('.hwContent').toggle('normal');
    if($(_this).css('margin-bottom')=='8px') {
        $(_this).closest('.row').next().find('.teamContent').slideDown('normal');
        $(_this).css('margin-bottom','0px');
        $(_this).next().css('margin-bottom','0px');
    }else{
        $(_this).closest('.row').next().find('.teamContent').slideUp('normal');
        setTimeout(function(){
            $(_this).css('margin-bottom','8px');
            $(_this).next().css('margin-bottom','8px');
        },300);
    }
});
function revealTeamMng() {
    $('#create-team').modal('close');
    $('#team-choose').css('display','none');
    $('#team-manage').css('display','block');
}
function revealTeamCheck() {
    $('#find-team').modal('close');
    $('#team-choose').css('display','none');
    $('#team-check').css('display','block');
}
$('.agree').click(function () {
    var _this=this;
    var _li=$(_this).parent().parent();
    $(_this).parent().parent().slideUp('normal');
    setTimeout(function () {
        $(_li).find('div a').css('display','none');
        $('#team-manage-mem').append(_li);
        $(_li).slideDown('normal');
    },300);

});
$('.disagree').click(function () {
    var _this=this;
    var _li=$(_this).parent().parent();
    $(_this).parent().parent().slideUp('normal');
});
function disableTeamApply() {
    $('#submit-team-apply').addClass('disabled').html('团队申请已提交');
}
var teamQuery={
    stuTS:{
        url:'/mooc/stu-team-status',
        data:{
            stuName:''
        }
    },
    stuTC:{
        url:'/mooc/stu-team-create',
        data:{
            teamName:'',
            teamInfo:'',
            stuName:''
        }
    },
    stuTM:{
        url:'/mooc/stu-team-manage',
        data:{
            stuName:''
        }
    },
    stuTI:{
        url:'/mooc/stu-team-info',
        data:{
            stuName:''
        }
    },
    stuTL:{
        url:'/mooc/stu-team-list',
    },
    stuTA:{
        url:'/mooc/stu-team-apply',
        data:{
            stuName:'',
            teamName:'',
        }
    },
    stuTMA:{
        url:'/mooc/stu-team-manage-approval',
        data:{
            stuName:'',
            approve:0
        }
    },
    stuTMS:{
        url:'/mooc/stu-team-manage-submit',
        data:{
            stuName:'',
        }
    },
    stuTMC:{
        url:'/mooc/stu-team-manage-check',
        data:{
            stuName:'',
        }
    }
};
var teamRet={
    stuTS:'',
    stuTC:'',
    stuTM:'',
    stuTI:'',
    stuTL:'',
    stuTA:'',
    stuTMA:'',
    stuTMS:'',
    stuTMC:'',
}

function setTeamValue(){
    var name=$('#name').text();
    teamQuery.stuTA.data.stuName=name;
    teamQuery.stuTC.data.stuName=name;
    teamQuery.stuTS.data.stuName=name;
    teamQuery.stuTM.data.stuName=name;
    teamQuery.stuTI.data.stuName=name;
    teamQuery.stuTMA.data.stuName=name;
    teamQuery.stuTMC.data.stuName=name;
    teamQuery.stuTMS.data.stuName=name;
}

function createTeam() {
    var _teamName=$('#teamname').val();
    var _teamInfo=$('#teaminfo').val();
    teamQuery.stuTC.data.teamName=_teamName;
    teamQuery.stuTC.data.teamInfo=_teamInfo;
    $('#team-manage-name').text(_teamName);
    $('#team-manage-info').text(_teamInfo);
    // $('#team-manage-app li').remove();
    // $('#team-manage-mem li').remove();
    teamCreate();
    revealTeamMng();
}
function getStuStatus() {
    $.get(teamQuery.stuTS.url,teamQuery.stuTS.data,function (json) {
        teamRet.stuTS=eval('('+json+')').status;
        alert('h'+teamRet.stuTS);
        if(1==teamRet.stuTS){
            getStuMng();
            revealTeamMng();
        }else if(2==teamRet.stuTS){
            getStuInfo();
            revealTeamCheck();
        }
    })
}
function getStuMng(){
    $.get(teamQuery.stuTM.url,teamQuery.stuTM.data,function (json) {
        teamRet.stuTM=eval('('+json+')');
        $('#team-manage-name').text(teamRet.stuTM.teamName);
        $('#team-manage-info').text(teamRet.stuTM.teamInfo);
        $.each(teamRet.stuTM.memApp,function (i,item) {
            $('#team-manage-app').append('<li class="collection-item"><div>'+item.name+'<a class="secondary-content waves-effect waves-light red z-depth-1 disagree">不同意</a><a class="secondary-content waves-effect waves-light cyan z-depth-1 agree">同意</a></div></li>');
            //TODO:可能click会有bug
        })
        $.each(teamRet.stuTM.memList,function (i,item) {
            $('#team-manage-mem').append('<li class="collection-item">'+item.name+'</li>')
        })
        // $('#team-manage-app').//TODO:fix
        // $('#team-manage-mem').//TOOD:fix
    })
}
function getStuInfo(){
    $.get(teamQuery.stuTI.url,teamQuery.stuTI.data,function (json) {
        teamRet.stuTI=eval('('+json+')');
        $('#team-check-name').text(teamRet.stuTI.teamName);
        $('#team-check-info').text(teamRet.stuTI.teamInfo);
        // $('#team-check-mem').//TOOD:fix
    })
}
function getStuTeamList() {
    $.get(teamQuery.stuTL.url,teamQuery.stuTL.data,function (json) {
        teamRet.stuTL=eval('('+json+')');
        //TODO:fix
    })
}
function setStuTeamApply(){
    $.post(teamQuery.stuTA.url,teamQuery.stuTA.data,function (json) {
        teamRet.stuTA=eval('('+json+')');
    })
}
function teamCreate(){
    $.post(teamQuery.stuTC.url,teamQuery.stuTC.data,function (json) {
        teamRet.stuTC=eval('('+json+')');
    })
}
function teamManageApproval(){
    $.post(teamQuery.stuTMA.url,teamQuery.stuTMA.data, function (json) {
        teamRet.stuTMA=eval('('+json+')');
    })
}
function teamManageSubmit(){
    $.post(teamQuery.stuTMS.url,teamQuery.stuTMS.data, function (json){
        teamRet.stuTMS=eval('('+json+')');
    })
}
function teamManegeCheck(){//待实现
    $.get(teamQuery.stuTMC.url,teamQuery.stuTMC.data, function (json) {
        teamRet.stuTMC=eval('('+json+')');
        // if(1==)
    })
}